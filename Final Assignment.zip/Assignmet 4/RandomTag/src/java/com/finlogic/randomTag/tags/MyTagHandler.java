package com.finlogic.randomTag.tags;
import java.util.Calendar;  
import java.util.Random;
import javax.servlet.jsp.JspException;  
import javax.servlet.jsp.JspWriter;  
import javax.servlet.jsp.tagext.TagSupport;  

public class MyTagHandler extends TagSupport{
    
    @Override
    public int doStartTag() throws JspException{
        JspWriter out=pageContext.getOut();
        Random rand = new Random();
        try{
            out.print(rand.nextFloat());
        }catch(Exception e){
                System.out.println(e);
        }
        return SKIP_BODY;
    }
    
}
