function getXMLHttpRequest() {
	var xmlHttpReq = false;
	// to create XMLHttpRequest object in non-Microsoft browsers
	if (window.XMLHttpRequest) {
		xmlHttpReq = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		try {
			// to create XMLHttpRequest object in later versions
			// of Internet Explorer
			xmlHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (exp1) {
			try {
				// to create XMLHttpRequest object in older versions
				// of Internet Explorer
				xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (exp2) {
				xmlHttpReq = false;
			}
		}
	}
	return xmlHttpReq;
}

function makeRequest(onElement,value) {
        if(onElement=="txtName"){
            document.getElementById("inValidName").innerHTML = "";
        }
        else{
            document.getElementById("inValidCountry").innerHTML = "";
        }
        var xmlHttpRequest = getXMLHttpRequest();
	xmlHttpRequest.onreadystatechange = getReadyStateHandler(xmlHttpRequest);
	//alert("Hereeee "+onElement+" value "+value);
        xmlHttpRequest.open("POST", "GetValidation.nj?eleName="+onElement+"&value="+value, true);
                
	xmlHttpRequest.setRequestHeader("Content-Type",
			"application/x-www-form-urlencoded");
	xmlHttpRequest.send(null);
}

function getReadyStateHandler(xmlHttpRequest) {

	// an anonymous function returned
	// it listens to the XMLHttpRequest instance
	return function() {
		if (xmlHttpRequest.readyState == 4) {
			if (xmlHttpRequest.status == 200) {
                            if(xmlHttpRequest.responseText=="inValidCountry"){
                                //alert("Invalid country")
                                document.getElementById("inValidCountry").innerHTML = "Please select country";
                            }
                            else if(xmlHttpRequest.responseText!="valid"){
                                //alert("Invalid name")
                                document.getElementById("inValidName").innerHTML = xmlHttpRequest.responseText;
                            }
			} else {
				alert("HTTP error " + xmlHttpRequest.status + ": " + xmlHttpRequest.statusText);
			}
		}
	};
}