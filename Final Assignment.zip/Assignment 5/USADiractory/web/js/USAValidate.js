function isValid(){
    //alert(document.getElementById("phone").value);
    var phone = document.getElementById("phone").value;
    document.getElementById("isValid").innerHTML = "";
    if(phone.match(/^\(?(\d{3})\)?[-\. ]?(\d{3})[-\. ]?(\d{4})( x\d{4})?$/)){
        document.getElementById("isValid").innerHTML = "<h3>Number is Valid</h3>";
    }
    else{
        document.getElementById("isValid").innerHTML = "<h3>Number is InValid</h3>";
    }
}


