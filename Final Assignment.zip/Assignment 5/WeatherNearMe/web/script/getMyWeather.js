var latitude,longitude;
var infoWeather = "sss";
var temp;
function getMyGeo() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        document.getElementById("location").innerHTML = "Geolocation is not supported by this browser.";
    }
    
}
function showPosition(position) {
    latitude = position.coords.latitude;
    longitude = position.coords.longitude;
    gettingJSON();
}


function gettingJSON(){
    $.getJSON("http://api.openweathermap.org/data/2.5/weather?lat="+latitude+"&lon="+longitude+"&APPID=15dad03a14c209a1b5a37081bd7facaa",function(json){
        infoWeather = JSON.stringify(json);
        temp = temperatureConverter(json.main.temp).toFixed(2);
        document.getElementById("location").innerHTML = "Place: "+json.name;
        document.getElementById("temprature").innerHTML = "Temprature: "+temp;
        setWeatherImage();
    });
    
}
function temperatureConverter(valNum) {
  valNum = parseFloat(valNum);
  return valNum-273.15;
}
function changeMatrics(){
    var calculated;
    if(document.getElementById("chkMetrics").checked){
        calculated = temp * 9 / 5 + 32;
        document.getElementById("temprature").innerHTML = "Temprature: "+calculated.toFixed(2);   
    }
    else{
        calculated = temp;
        document.getElementById("temprature").innerHTML = "Temprature: "+calculated;
    }
    setWeatherImage();
}
function setWeatherImage(){
    if(temp<20){
        document.getElementById("imgWeather").src="images/snowy-mountains.jpg";
    }
    else if(temp>=20 && temp<35){
        document.getElementById("imgWeather").src="images/natural.jpg";
    }
    else{
        document.getElementById("imgWeather").src="images/HotDesert.jpg";
    }
    
}
