
function getLongest(){
    var text = document.getElementById("sentence").value;
    text = text.toString();
    if(!text || text == ""){
        alert("Please enter senetence");
        return;
    }
    text = text.replace(".","");
    var element = text.split(" ");
    var length = 0;
    var longest;
    for(var s in element){
        //alert(element[s].length);
        if(element[s].length>length){
          length = element[s].length;  
          longest = element[s];
        }
    }
    var lbLongest = document.getElementById("longestWord");
    lbLongest.innerHTML = "Longest Word in given sentence is "+longest;
}

